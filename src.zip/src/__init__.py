# src/__init__.py
"""Supplement analysis system package"""
__version__ = "1.0.0"